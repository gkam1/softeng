﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Register : Form
    {
        public string email, name, surname, bio, password;
        public int age, phone, payment_account;

        public Register()
        {
            InitializeComponent();
        }
        public Register(string email, string name, string surname, int age, int phone, int payment_account, string bio, string password)
        {
            this.email = email;
            this.name = name;
            this.surname = surname;
            this.bio = bio;
            this.password = password;
            this.age = age;
            this.phone = phone;
            this.payment_account = payment_account;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void PaymentAccountTextBox_TextChanged(object sender, EventArgs e)
        {
            this.payment_account = int.Parse(PaymentAccountTextBox.Text);
        }

        private void PhoneTextBox_TextChanged(object sender, EventArgs e)
        {
            this.phone = int.Parse(PhoneTextBox.Text);
        }

        private void AgeTextBox_TextChanged(object sender, EventArgs e)
        {
            this.age = int.Parse(AgeTextBox.Text);
        }

        private void EmailTextBox_TextChanged(object sender, EventArgs e)
        {
            this.email = EmailTextBox.Text;
        }

        private void SurnameTextBox_TextChanged(object sender, EventArgs e)
        {
            this.surname = SurnameTextBox.Text;
        }

        private void NameTextBox_TextChanged(object sender, EventArgs e)
        {
            this.name = NameTextBox.Text;
        }

        private void PasswordTextBox_TextChanged(object sender, EventArgs e)
        {
            this.password = PasswordTextBox.Text;
        }

        private void textBox8_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void GoHomePageButton_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AccountRegister();

        }



        public Boolean AccountRegister()
        {
            if (Verification.Verify(this) == true)
            {
                MessageBox.Show("Registration Complete!");
                this.Hide();
                new Form2().Show();
                return true;
            }
            else
            {
                MessageBox.Show("There was a problem with your form,check again.");
                return false;
            }
        }
    }
}
