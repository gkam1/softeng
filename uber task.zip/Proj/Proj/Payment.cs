﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Payment : Form
    {
        public int payment_id;
        //protected string payment_credentials[100];
        protected Boolean payment_status;
        //Payment(Task_id);
        public Payment()
        {

            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
    }

