﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Myproj : Form
    {
        Employee User;
        public Myproj(Employee User)
        {
            this.User = User;
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void GoHomePageButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show(User.name);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void HprojList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void HtasksList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PAtasksList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PAprojList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CAprojList_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void CAtasksList_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}
