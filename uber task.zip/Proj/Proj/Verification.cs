﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public abstract class Verification
    {
        public static Boolean Verify(string name,string password) {

            try
            {

                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);
                cnn.Open();
                MySqlDataAdapter sda = new MySqlDataAdapter("SELECT COUNT(*) FROM user WHERE name='" + name + "' AND password='" + password + "'", cnn);
                /* in above line the program is selecting the whole data from table and the matching it with the user name and password provided by user. */
                DataTable dt = new DataTable(); //this is creating a virtual table   
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    return true;
                    cnn.Close();
                }
                else
                    return false;
                    cnn.Close();
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public static Boolean Verify(Register re) {

            try
            {
                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);

                var stm = "insert into user (name,surname,age,phone,payment_account,bio,password,email) values ('" + re.name + "','" + re.surname + "','" + re.age + "','" + re.phone + "','" + re.payment_account + "','" + re.bio + "','" + re.password + "','" + re.email + "')";
                var cmd = new MySqlCommand(stm, cnn);
                cnn.Open();
                int res = cmd.ExecuteNonQuery();

                // Check Error
                if (res < 0)
                {
                    cnn.Close();
                    return false;
                }
                else { 
                cnn.Close();
                return true;
                }
            }
            catch (Exception ex)
            { 
                Console.WriteLine(ex.Message);
                return false;
            }
        }
       // public static Boolean Verify(Task t) { return true; }

    }
}
