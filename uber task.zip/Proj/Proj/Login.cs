﻿using MySql.Data.MySqlClient;
using Proj;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Login : Form
    {

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            Employee User = AccountLogin(textBox1.Text, textBox2.Text);
            if (User.name != null)
            { this.Hide();
                Myproj Myproj = new Myproj(User);
                new Home(Myproj).Show(); }
     
        }
        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = '*';
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public Employee AccountLogin(string s1, string s2)
        {
            Employee user = new Employee(null, null, null, null, null, 0, 0, 0, 0);
            if (Verification.Verify(s1, s2) == true)
            {

                //new Home().Show();

                try
                {
                    string connetionString;
                    connetionString = "server=localhost;user id=root;database=databases;password=";
                    MySqlConnection cnn = new MySqlConnection(connetionString);
                    cnn.Open();
                    string sql = @"SELECT email,name,surname,age,phone,payment_account,bio,id,password FROM user WHERE name='" + s1 + "' AND password='" + s2 + "'";
                    MySqlCommand cmd = new MySqlCommand(sql, cnn);
                    MySqlDataReader reader = cmd.ExecuteReader();
                    if (reader.Read())
                    {
                        Employee User = new Employee(reader["email"].ToString(), reader["name"].ToString(), reader["surname"].ToString(), reader["bio"].ToString(), reader["password"].ToString(), int.Parse(reader["age"].ToString()), int.Parse(reader["phone"].ToString()), int.Parse(reader["payment_account"].ToString()), int.Parse(reader["id"].ToString()));
                        return User;
                    }
                    else { return user; }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("There was a problem logging you in");
                    MessageBox.Show(ex.Message);
                    return user;
                }
            }
            else { MessageBox.Show("Your name and password are wrong,or there was a problem connecting to the server."); return user; }
        }
    }

}


/*
  try
            {

             

                string connetionString;
                connetionString = "server=localhost;user id=root;database=databases;password=";
                MySqlConnection cnn = new MySqlConnection(connetionString);

     
              
cnn.Open();
                var queryStr = "SELECT password FROM user WHERE name='" + textBox1.Text + "'";
var cmd = new MySql.Data.MySqlClient.MySqlCommand(queryStr, cnn);
var dr = cmd.ExecuteReader();
string hashedpassword = null;
                // Now check if any rows returned.
                if (dr.HasRows)
                {
                    dr.Read();// Get first record.
                    hashedpassword = dr.GetString(0);// Get value of first column as string.
                    MessageBox.Show(hashedpassword);
                }
                var result = SecurePasswordHasher.Verify("test", hashedpassword);
                if (result = true)
                {
                    // I have made a new page called home page. If the user is successfully authenticated then the form will be moved to the next form 
                    this.Hide();
                    cnn.Close();
                    new Form2().Show();
                }
                else
                    MessageBox.Show("Invalid username or password");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
 */