﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Register : Form
    {
        public string email = "textBox1.Text", name = "textBox2.Text", surname = "textBox3.Text", bio = "textBox4.Text", password = "textBox5.Text";
        public int age = 14, phone = 698632768, payment_account = 78342;

        private void button1_Click(object sender, EventArgs e)
        {
            if (Verification.Verify(this) == true)
            {
                MessageBox.Show("Registration Complete!");
                this.Hide();
                new Form2().Show();
            }
            else
            {
                MessageBox.Show("There was a problem with your form,check again.");
            }
        }

        public Register(){ 
            InitializeComponent(); 
    }
        public Register(string email, string name, string surname, int age, int phone, int payment_account, string bio, string password)
        {
            this.email = email;
            this.name = name;
            this.surname = surname;
            this.bio = bio;
            this.password = password;
            this.age = age;
            this.phone = phone;
            this.payment_account = payment_account;
        }


        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
