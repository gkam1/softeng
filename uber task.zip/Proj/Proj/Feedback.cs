﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Feedback : Form
    {
        public int critics_id;
        public string critics;
        //  public Feedback Feedback(task_id);
        //public string GetFeedback(critics_id, Employer.id, Employee.id);
        //public string SendFeedback(critics_id, Employer.id, Employee.id);
        public Feedback()
        {

            InitializeComponent();
        }
        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Feedback_Load(object sender, EventArgs e)
        {

        }
    }
    }

