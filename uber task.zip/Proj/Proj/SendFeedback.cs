﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class SendFeedback : Form
    {
        //public Boolean SendFeedback(critics_id, Employer.id, Employee.id);
        public SendFeedback()
        {
            
            InitializeComponent();
        }
    }
}
