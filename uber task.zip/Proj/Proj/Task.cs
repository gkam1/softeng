﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proj
{
    public class Task
    {
        public string title;
        public string description;
        public string[] list;
        public double payment;
        public Boolean proof;
        public int id;

        public Task(string task_title, string task_description, string[] task_list, double payment_price, Boolean proof_of_work, int task_id)
        {
            this.title = task_title;
            this.description = task_description;
            this.list = task_list;
            this.payment = payment_price;
            this.proof = proof_of_work;
            this.id = task_id;
        }

        static void CreateTask(Boolean task_verified)
        {

        }

        static void GetTask(string title)
        {

        }

        static void GetTask()
        {

        }
    }
}
