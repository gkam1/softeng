﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Chat : Form
    {
        public int chat_id;
       // private readonly string chatters = new string[100];
        public Boolean message_check;
        //public string GetM(chat_id, Employee.id, Employer.id) { };
        //void Chat(task_id);
        //public string GetM(chat_id, Employer.id, Empoyee.id);
        //public Boolean SendM(chat_id, Employer.id, Employee.id);
        public Chat()
        {

            InitializeComponent(); }
    
        private void Chat_Load(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            MessageBox.Show("OK");
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("Sent!");
        }
    }
    }

