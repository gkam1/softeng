﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proj
{
    public partial class Home : Form
    {
        Myproj Myproj;
        public Home(Myproj Myproj)
        {
            this.Myproj = Myproj;
            InitializeComponent();
        }

        private void CommunicationButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Chat().Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Myproj.Show();
        }

        private void CloseHomeButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Application.Exit();
        }

        private void FeedbackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new Feedback().Show();
        }

        private void FindTaskProjButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            new find_task().Show();
        }
    }
}
