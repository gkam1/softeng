﻿namespace Proj
{
    partial class Myproj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.GoHomePageButton = new System.Windows.Forms.Button();
            this.HtasksList = new System.Windows.Forms.ListBox();
            this.listBox3 = new System.Windows.Forms.ListBox();
            this.HprojList = new System.Windows.Forms.ListBox();
            this.PAprojList = new System.Windows.Forms.ListBox();
            this.CAprojList = new System.Windows.Forms.ListBox();
            this.CAtasksList = new System.Windows.Forms.ListBox();
            this.PAtasksList = new System.Windows.Forms.ListBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.GoHomePageButton);
            this.panel1.Controls.Add(this.HtasksList);
            this.panel1.Controls.Add(this.listBox3);
            this.panel1.Controls.Add(this.HprojList);
            this.panel1.Controls.Add(this.PAprojList);
            this.panel1.Controls.Add(this.CAprojList);
            this.panel1.Controls.Add(this.CAtasksList);
            this.panel1.Controls.Add(this.PAtasksList);
            this.panel1.Controls.Add(this.listBox1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Location = new System.Drawing.Point(235, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(595, 642);
            this.panel1.TabIndex = 0;
            // 
            // GoHomePageButton
            // 
            this.GoHomePageButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.GoHomePageButton.ForeColor = System.Drawing.Color.White;
            this.GoHomePageButton.Location = new System.Drawing.Point(194, 582);
            this.GoHomePageButton.Name = "GoHomePageButton";
            this.GoHomePageButton.Size = new System.Drawing.Size(180, 44);
            this.GoHomePageButton.TabIndex = 4;
            this.GoHomePageButton.Text = "Go To Homepage";
            this.GoHomePageButton.UseVisualStyleBackColor = false;
            this.GoHomePageButton.Click += new System.EventHandler(this.GoHomePageButton_Click);
            // 
            // HtasksList
            // 
            this.HtasksList.FormattingEnabled = true;
            this.HtasksList.ItemHeight = 49;
            this.HtasksList.Location = new System.Drawing.Point(13, 477);
            this.HtasksList.Name = "HtasksList";
            this.HtasksList.Size = new System.Drawing.Size(231, 53);
            this.HtasksList.TabIndex = 3;
            this.HtasksList.SelectedIndexChanged += new System.EventHandler(this.HtasksList_SelectedIndexChanged);
            // 
            // listBox3
            // 
            this.listBox3.FormattingEnabled = true;
            this.listBox3.ItemHeight = 49;
            this.listBox3.Location = new System.Drawing.Point(13, 477);
            this.listBox3.Name = "listBox3";
            this.listBox3.Size = new System.Drawing.Size(231, 53);
            this.listBox3.TabIndex = 3;
            // 
            // HprojList
            // 
            this.HprojList.FormattingEnabled = true;
            this.HprojList.ItemHeight = 49;
            this.HprojList.Location = new System.Drawing.Point(340, 477);
            this.HprojList.Name = "HprojList";
            this.HprojList.Size = new System.Drawing.Size(231, 53);
            this.HprojList.TabIndex = 3;
            this.HprojList.SelectedIndexChanged += new System.EventHandler(this.HprojList_SelectedIndexChanged);
            // 
            // PAprojList
            // 
            this.PAprojList.FormattingEnabled = true;
            this.PAprojList.ItemHeight = 49;
            this.PAprojList.Location = new System.Drawing.Point(340, 339);
            this.PAprojList.Name = "PAprojList";
            this.PAprojList.Size = new System.Drawing.Size(231, 53);
            this.PAprojList.TabIndex = 3;
            this.PAprojList.SelectedIndexChanged += new System.EventHandler(this.PAprojList_SelectedIndexChanged);
            // 
            // CAprojList
            // 
            this.CAprojList.FormattingEnabled = true;
            this.CAprojList.ItemHeight = 49;
            this.CAprojList.Location = new System.Drawing.Point(340, 194);
            this.CAprojList.Name = "CAprojList";
            this.CAprojList.Size = new System.Drawing.Size(231, 53);
            this.CAprojList.TabIndex = 3;
            this.CAprojList.SelectedIndexChanged += new System.EventHandler(this.CAprojList_SelectedIndexChanged);
            // 
            // CAtasksList
            // 
            this.CAtasksList.FormattingEnabled = true;
            this.CAtasksList.ItemHeight = 49;
            this.CAtasksList.Location = new System.Drawing.Point(13, 194);
            this.CAtasksList.Name = "CAtasksList";
            this.CAtasksList.Size = new System.Drawing.Size(231, 53);
            this.CAtasksList.TabIndex = 3;
            this.CAtasksList.SelectedIndexChanged += new System.EventHandler(this.CAtasksList_SelectedIndexChanged);
            // 
            // PAtasksList
            // 
            this.PAtasksList.FormattingEnabled = true;
            this.PAtasksList.ItemHeight = 49;
            this.PAtasksList.Location = new System.Drawing.Point(13, 339);
            this.PAtasksList.Name = "PAtasksList";
            this.PAtasksList.Size = new System.Drawing.Size(231, 53);
            this.PAtasksList.TabIndex = 3;
            this.PAtasksList.SelectedIndexChanged += new System.EventHandler(this.PAtasksList_SelectedIndexChanged);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 49;
            this.listBox1.Location = new System.Drawing.Point(13, 194);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(231, 53);
            this.listBox1.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(89, 455);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(138, 49);
            this.label5.TabIndex = 2;
            this.label5.Text = "History";
            this.label5.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(53, 311);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(307, 49);
            this.label4.TabIndex = 2;
            this.label4.Text = "Pending Assigned";
            this.label4.Click += new System.EventHandler(this.label3_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(425, 455);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(138, 49);
            this.label8.TabIndex = 2;
            this.label8.Text = "History";
            this.label8.Click += new System.EventHandler(this.label3_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(381, 311);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(307, 49);
            this.label7.TabIndex = 2;
            this.label7.Text = "Pending Assigned";
            this.label7.Click += new System.EventHandler(this.label3_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(381, 172);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(326, 49);
            this.label9.TabIndex = 2;
            this.label9.Text = "Currently Assigned";
            this.label9.Click += new System.EventHandler(this.label3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 172);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(326, 49);
            this.label3.TabIndex = 2;
            this.label3.Text = "Currently Assigned";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(395, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(117, 34);
            this.label2.TabIndex = 1;
            this.label2.Text = "My Project";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(67, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 34);
            this.label1.TabIndex = 1;
            this.label1.Text = "My Tasks";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(84)))), ((int)(((byte)(0)))));
            this.panel2.Controls.Add(this.label6);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(595, 79);
            this.panel2.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(230, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(334, 83);
            this.label6.TabIndex = 1;
            this.label6.Text = "UBER TASK";
            // 
            // Myproj
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(20F, 49F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(230)))), ((int)(((byte)(126)))), ((int)(((byte)(34)))));
            this.ClientSize = new System.Drawing.Size(1067, 658);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(161)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Myproj";
            this.Text = "My Proj";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button GoHomePageButton;
        private System.Windows.Forms.ListBox HtasksList;
        private System.Windows.Forms.ListBox listBox3;
        private System.Windows.Forms.ListBox HprojList;
        private System.Windows.Forms.ListBox PAprojList;
        private System.Windows.Forms.ListBox CAprojList;
        private System.Windows.Forms.ListBox CAtasksList;
        private System.Windows.Forms.ListBox PAtasksList;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Label label6;
    }
}